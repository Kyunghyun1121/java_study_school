package mylib;

public class KButton extends KAbstractButton {

	public KButton(String string) {
		super(string);
	}



}
